/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package capa.logica;

/**
 *
 * @author a
 */
public class Usuario {

    /**
     *
     */
    public String nombreDelUsuario = " ";

    /**
     *
     */
    public String claveDelUsuario = " ";

    /**
     *
     * @return
     */
    public String getNombreDelUsuario() {
        return nombreDelUsuario;
    }

    /**
     *
     * @param nombreDelUsuario
     */
    public void setNombreDelUsuario(String nombreDelUsuario) {
        this.nombreDelUsuario = nombreDelUsuario;
    }

    /**
     *
     * @return
     */
    public String getClaveDelUsuario() {
        return claveDelUsuario;
    }

    /**
     *
     * @param claveDelUsuario
     */
    public void setClaveDelUsuario(String claveDelUsuario) {
        this.claveDelUsuario = claveDelUsuario;
    }
    
    

    
    
    
}
