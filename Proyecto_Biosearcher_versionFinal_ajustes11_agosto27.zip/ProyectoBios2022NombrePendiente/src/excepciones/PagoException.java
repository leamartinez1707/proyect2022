/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package excepciones;

/**
 *
 * @author a
 */
public class PagoException extends Exception{
    /**
     * Creates a new instance of <code>NegocioException</code> without detail
     * message.
     */
    public PagoException() {
    }

    /**
     * Constructs an instance of <code>NegocioException</code> with the
     * specified detail message.
     *
     * @param msg the detail message.
     */
    public PagoException(String msg) {
        super(msg);
    }
}
