/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package capa.logica;

/**
 *
 * @author Leandro
 */
public class Afiliacion {

        String idAfiliacion;
        String nombreAfiliacion;
        String ciAfiliado;
        String descripcion;

    public String getIdAfiliacion() {
        return idAfiliacion;
    }

    public void setIdAfiliacion(String idAfiliacion) {
        this.idAfiliacion = idAfiliacion;
    }

    public String getNombreAfiliacion() {
        return nombreAfiliacion;
    }

    public void setNombreAfiliacion(String nombreAfiliacion) {
        this.nombreAfiliacion = nombreAfiliacion;
    }

    public String getCiAfiliado() {
        return ciAfiliado;
    }

    public void setCiAfiliado(String ciAfiliado) {
        this.ciAfiliado = ciAfiliado;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }
    
}
